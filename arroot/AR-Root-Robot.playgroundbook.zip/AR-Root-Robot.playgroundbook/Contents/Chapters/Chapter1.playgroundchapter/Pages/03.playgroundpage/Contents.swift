//#-hidden-code
//
//  VirtualRobotModel.swift
//
//  Copyright © 2018 Root Robotics Inc. All rights reserved.

import PlaygroundSupport

let proxy = PlaygroundPage.current.liveView as? PlaygroundRemoteLiveViewProxy

PlaygroundPage.current.needsIndefiniteExecution = true

public final class Root {
    private var whenProgramStartedActions: [PlaygroundValue] = []
    
    public func whenProgramStarted(_ actions: () -> Void) {
        whenProgramStartedActions.removeAll()
        actions()
        proxy?.send(.array(whenProgramStartedActions))
    }
    
    public func place() {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("place"), "argInt": PlaygroundValue.integer(0), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }

    public func move(_ cm: Int = 16) {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("move"), "argInt": PlaygroundValue.integer(cm), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }
    
    public func speeds(left: Int, right: Int) {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("setWheels"), "argInt": PlaygroundValue.integer(left), "argInt2": PlaygroundValue.integer(right), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }
    
    public func wait(sec: Double) {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("wait"), "argInt": PlaygroundValue.integer(0), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(sec)]))
    }

    public func turn(_ deg: Int = 90) {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("rotate"), "argInt": PlaygroundValue.integer(deg), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }

    public func markerDown() {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("marker"), "argInt": PlaygroundValue.integer(1), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }

    public func markerAndEraserUp() {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("marker"), "argInt": PlaygroundValue.integer(0), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }
}
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, robot, ., move(_:), turn(_:), markerDown(), markerAndEraserUp())

//#-end-hidden-code

/*:#localized(key: "FirstProseBlock")
 # Make Your Mark
 
 Make Root an artist by putting a marker in its center.
 
 To activate Root’s marker, use the `markerDown()` command. With the marker down, Root leaves a path wherever it drives.
 
 To pick the marker back up, use the `markerAndEraserUp()` command.
 
 ![image](markerDown.png)
 
 Try coding Root to draw a dashed line with `markerDown()`, `move()`, and `markerAndEraserUp()` commands.

 */
let robot = Root()

robot.whenProgramStarted {
    robot.place()
    //#-editable-code
    robot.markerDown()
    robot.move(16)
    
    //#-end-editable-code
}
