//#-hidden-code
//
//  VirtualRobotModel.swift
//
//  Copyright © 2018 Root Robotics Inc. All rights reserved.

import PlaygroundSupport

let proxy = PlaygroundPage.current.liveView as? PlaygroundRemoteLiveViewProxy

PlaygroundPage.current.needsIndefiniteExecution = true

public final class Root {
    private var whenProgramStartedActions: [PlaygroundValue] = []
    
    public func whenProgramStarted(_ actions: () -> Void) {
        whenProgramStartedActions.removeAll()
        actions()
        proxy?.send(.array(whenProgramStartedActions))
    }
    
    public func place() {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("place"), "argInt": PlaygroundValue.integer(0), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }

    public func move(_ cm: Int) {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("move"), "argInt": PlaygroundValue.integer(cm), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }
    
    public func speeds(left: Int, right: Int) {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("setWheels"), "argInt": PlaygroundValue.integer(left), "argInt2": PlaygroundValue.integer(right), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }
    
    public func wait(sec: Double) {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("wait"), "argInt": PlaygroundValue.integer(0), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(sec)]))
    }

    public func turn(_ deg: Int) {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("rotate"), "argInt": PlaygroundValue.integer(deg), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }

    public func markerDown() {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("marker"), "argInt": PlaygroundValue.integer(1), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }

    public func markerAndEraserUp() {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("marker"), "argInt": PlaygroundValue.integer(0), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }
}

//#-code-completion(everything, hide)
//#-code-completion(identifier, show, robot, ., whenProgramStarted(_:), place())
//#-end-hidden-code

/*:#localized(key: "FirstProseBlock")
 # Meet Root
 
 Root is a robot that you can code to move, draw, sing, glow, and react to the world around it. In this Playground, you will play with a Virtual Root robot using Augmented Reality (AR)!
 
 AR uses your device’s camera to place a Virtual Root in the room with you, anywhere you’d like!
 
 * Note: You need an ARKit compatible device to use Virtual Root.
 
 Move your device around to choose where to place your Virtual Root, then tap “Run My Code” to watch Root make you some art!
 */
let robot = Root()
robot.whenProgramStarted {
    robot.place()
    robot.markerDown()
    for _ in 0..<9 {
        robot.speeds(left: 7, right: 10)
        robot.wait(sec: 1)
        robot.speeds(left: 10, right: 5)
        robot.wait(sec: 2.5)
    }
    robot.speeds(left: 7, right: 10)
    robot.wait(sec: 0.2)
    robot.speeds(left: 0, right: 0)
    robot.markerAndEraserUp()
    robot.turn(90)
    robot.move(10)
    robot.turn(-80)
    robot.move(10)
}
