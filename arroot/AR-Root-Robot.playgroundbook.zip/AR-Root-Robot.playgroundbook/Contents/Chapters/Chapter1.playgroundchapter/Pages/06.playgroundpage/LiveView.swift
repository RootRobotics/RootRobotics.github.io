//
//  VirtualRobotModel.swift
//
//  Copyright © 2018 Root Robotics Inc. All rights reserved.

import UIKit
import PlaygroundSupport

// Instantiate a new instance of the live view from the book's auxiliary sources and pass it to PlaygroundSupport.
DispatchQueue.main.async {
    let page = PlaygroundPage.current
    let liveView = instantiateLiveView()
    page.liveView = liveView
}
