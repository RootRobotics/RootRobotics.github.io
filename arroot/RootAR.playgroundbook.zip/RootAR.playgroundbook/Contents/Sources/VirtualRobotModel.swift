//
//  VirtualRobotModel.swift
//
//  Copyright © 2018 Root Robotics Inc. All rights reserved.

import PlaygroundSupport
import UIKit

private struct RobotProperty {
    static let topSpeed: CGFloat = 0.1 // meters/sec
    static let axelWidth: CGFloat = 0.102 // meters
    static let halfAxelWidth: CGFloat = RobotProperty.axelWidth*0.5 // meters
    static let accelerationRampTimeSetSpeed: TimeInterval = 0.2 //sec
    static let accelerationRampTimeDistanceAndRotate: TimeInterval = 0.4 //sec
}

public struct UIProperty {
    static let pixelsInMeters: CGFloat = 2000
    static let layerEdgeToCenter: CGFloat = 2000
}

public final class VirtualRobotModel {
    
    internal var currentCenterX: CGFloat = 0.0 //meters
    internal var currentCenterY: CGFloat = 0.0 //meters
    internal var heading: CGFloat = 0.0 //rad
    
    private var leftWheelPosition: CGPoint {
        return CGPoint(x: RobotProperty.halfAxelWidth*cos(heading) - currentCenterX, y: RobotProperty.halfAxelWidth*sin(heading) - currentCenterY)
    }
    private var rightWheelPosition: CGPoint {
        return CGPoint(x: RobotProperty.halfAxelWidth*cos(heading) - currentCenterX, y: RobotProperty.halfAxelWidth*sin(heading) + currentCenterY)
    }
    private var leftWheelSpeed = CGFloat()
    private var rightWheelSpeed = CGFloat()
    private var previousLeftWheelSpeed: CGFloat = 0.0
    private var previousRightWheelSpeed: CGFloat = 0.0
    internal var path = [UIBezierPath]()
    private var markerDown = false
    private var timestamp = Date().timeIntervalSince1970
    private var updateTwice = true
    private var startMovementTimestamp: TimeInterval?

    @objc internal func update() {
        DispatchQueue.main.async {
            let nextTimestamp = Date().timeIntervalSince1970
            let timestampFloatDelta = CGFloat(nextTimestamp - self.timestamp)
            self.timestamp = nextTimestamp
            
            self.checkAndChangeMotorsIfTriggered(timestampFloatDelta)
            self.addToPath()
        }
    }
    
    private func incrementDistanceTraveled(_ timestampFloatDelta: CGFloat, leftWheelSpeed: CGFloat, rightWheelSpeed: CGFloat) {
        DispatchQueue.main.async {
            guard (leftWheelSpeed != 0.0 || rightWheelSpeed != 0.0) else { return }
            let wheelSpeedDifference = leftWheelSpeed - rightWheelSpeed
            let wheelSpeedSum = leftWheelSpeed + rightWheelSpeed
            let rightDistance = rightWheelSpeed * timestampFloatDelta
            
            if wheelSpeedDifference == 0.0 {
                self.translationDisplacement(with: rightDistance)
                self.addToPath()
                return
            }
            else if wheelSpeedSum == 0 {
                self.rotationDisplacement(with: rightWheelSpeed * timestampFloatDelta)
                return
            }
            else {
                let leastWheelSpeed = abs(leftWheelSpeed) > abs(rightWheelSpeed) ? rightWheelSpeed : leftWheelSpeed
                let leftDistance = leftWheelSpeed * timestampFloatDelta
                let leastDistance = leftWheelSpeed > rightWheelSpeed ? rightDistance : leftDistance
                let wheelSpeedSumDirection = wheelSpeedSum > 0 ? wheelSpeedSum : -wheelSpeedSum
                
                if leftWheelSpeed.isLess(than: 0.0) {
                    if rightWheelSpeed.isLess(than: 0.0) { // both neg
                        let pivotAngle = -wheelSpeedDifference * timestampFloatDelta / RobotProperty.axelWidth
                        self.translationDisplacement(with: leastDistance)
                        self.pivotDisplacement(with: pivotAngle)
                    }
                    else { // left neg, right pos
                        self.rotationDisplacement(with: leastWheelSpeed * timestampFloatDelta)
                        let pivotAngle = -wheelSpeedSumDirection * timestampFloatDelta / RobotProperty.axelWidth
                        self.pivotDisplacement(with: pivotAngle)
                    }
                }
                else {
                    if !rightWheelSpeed.isLess(than: 0.0) { // both pos
                        let pivotAngle = -wheelSpeedDifference * timestampFloatDelta / RobotProperty.axelWidth
                        self.translationDisplacement(with: leastDistance)
                        self.pivotDisplacement(with: pivotAngle)
                    }
                    else { //left pos, right neg
                        self.rotationDisplacement(with: leastWheelSpeed * timestampFloatDelta)
                        let pivotAngle = wheelSpeedSumDirection * timestampFloatDelta / RobotProperty.axelWidth
                        self.pivotDisplacement(with: pivotAngle)
                    }
                }
            }
        }
    }
    
    private func checkAndChangeMotorsIfTriggered(_ deltaTime: CGFloat) {
        DispatchQueue.main.async {
            let ts = Date().timeIntervalSince1970
            if let timestamp = self.setWheelSpeedsToZeroTimestamp,
                timestamp < ts {  // when robot stops
                let prevLeft = self.leftWheelSpeed
                let prevRight = self.rightWheelSpeed
                self.setWheelSpeed(leftLevel: 0, rightLevel: 0, distance: !self.isRotate, rotate: self.isRotate)
                self.setWheelSpeedsToZeroTimestamp = nil
                self.incrementDistanceTraveled(deltaTime - CGFloat(ts - timestamp), leftWheelSpeed: prevLeft, rightWheelSpeed: prevRight)
                self.incrementDistanceTraveled(CGFloat(ts - timestamp), leftWheelSpeed: self.leftWheelSpeed, rightWheelSpeed: self.rightWheelSpeed)
                self.startMovementTimestamp = nil
            }
            else if let timestampValue = self.setWheelSpeedsToValueAtTime,
                timestampValue.timestamp < ts { // inbetween ramping of set wheels
                let prevLeft = self.leftWheelSpeed
                let prevRight = self.rightWheelSpeed
                self.leftWheelSpeed = timestampValue.left
                self.rightWheelSpeed = timestampValue.right
                self.setWheelSpeedsToValueAtTime = nil
                
                self.incrementDistanceTraveled(deltaTime - CGFloat(ts - timestampValue.timestamp), leftWheelSpeed: prevLeft, rightWheelSpeed: prevRight)
                self.incrementDistanceTraveled(CGFloat(ts - timestampValue.timestamp), leftWheelSpeed: self.leftWheelSpeed, rightWheelSpeed: self.rightWheelSpeed)
                self.startMovementTimestamp = nil
            } else if let start = self.startMovementTimestamp { // when robot starts
                let prevLeft = self.previousLeftWheelSpeed
                let prevRight = self.previousRightWheelSpeed
                self.incrementDistanceTraveled(deltaTime - CGFloat(ts - start), leftWheelSpeed: prevLeft, rightWheelSpeed: prevRight)
                self.incrementDistanceTraveled(CGFloat(ts - start), leftWheelSpeed: self.leftWheelSpeed, rightWheelSpeed: self.rightWheelSpeed)
            }
            else { // typical steady state
                self.incrementDistanceTraveled(deltaTime, leftWheelSpeed: self.leftWheelSpeed, rightWheelSpeed: self.rightWheelSpeed)
            }
            self.startMovementTimestamp = nil
        }
    }
    
    private func rotationDisplacement(with distance: CGFloat) {
        self.heading = heading + distance * 2 / RobotProperty.axelWidth
    }
    
    private func translationDisplacement(with distance: CGFloat) {
        currentCenterX += distance*cos(heading)
        currentCenterY += distance*sin(heading)
    }
    
    private func pivotDisplacement(with angle: CGFloat) {
        let xDeltaPrime = RobotProperty.halfAxelWidth * (1 - cos(abs(angle)))
        let yDeltaPrime = RobotProperty.halfAxelWidth * sin(abs(angle))
        currentCenterX += (xDeltaPrime + yDeltaPrime)*cos(heading)
        currentCenterY += (-xDeltaPrime + yDeltaPrime)*sin(heading)
        heading = heading + angle
    }
    
    private func addToPath() {
        DispatchQueue.main.async {
        let point: CGPoint = CGPoint(x: self.currentCenterX*UIProperty.pixelsInMeters + UIProperty.layerEdgeToCenter, y: self.currentCenterY*UIProperty.pixelsInMeters + UIProperty.layerEdgeToCenter)
            if self.markerDown {
                self.path.first?.addLine(to: point)
                self.path.first?.move(to: point)
            }
            else {
                self.path.first?.move(to: point)
            }
        }
    }
    
    private var setWheelSpeedsToZeroTimestamp: Double?
    private func flagWheelStop(time: TimeInterval) {
        setWheelSpeedsToZeroTimestamp = Date().timeIntervalSince1970 + time
    }
    
    private var setWheelSpeedsToValueAtTime: (timestamp: Double, left: CGFloat, right: CGFloat)?
 
    private func flagWheelSpeedToValue(time: TimeInterval, left: CGFloat, right: CGFloat) {
        setWheelSpeedsToValueAtTime = (Date().timeIntervalSince1970 + time, left, right)
    }
    
    internal func setWheelSpeed(leftLevel: CGFloat, rightLevel: CGFloat, completionTime: Double? = nil, distance: Bool = false, rotate: Bool = false, completion: @escaping () -> Void = {}) { // values from 0 -> 10, percentage of top speed
        var leftLevelAdjusted = leftLevel
        var rightLevelAdjusted = rightLevel
        if leftLevelAdjusted > setSpeedScalar {
            leftLevelAdjusted = setSpeedScalar
        }
        else if leftLevelAdjusted < -setSpeedScalar {
            leftLevelAdjusted = -setSpeedScalar
        }
        if rightLevelAdjusted > setSpeedScalar {
            rightLevelAdjusted = setSpeedScalar
        }
        else if leftLevelAdjusted < -setSpeedScalar {
            leftLevelAdjusted = -setSpeedScalar
        }
        DispatchQueue.main.async {
            self.previousLeftWheelSpeed = self.leftWheelSpeed
            self.previousRightWheelSpeed = self.rightWheelSpeed
            let currentLeft = self.leftWheelSpeed
            let currentRight = self.rightWheelSpeed
            let nextLeftWheelSpeed = leftLevelAdjusted * self.speedUp * RobotProperty.topSpeed / 10
            let nextRightWheelSpeed = rightLevelAdjusted * self.speedUp * RobotProperty.topSpeed / 10
            let approximateAccelerationSpeedLeft = (nextLeftWheelSpeed + currentLeft) * 0.5
            let approximateAccelerationSpeedRight = (nextRightWheelSpeed + currentRight) * 0.5
            var accelerationTime = RobotProperty.accelerationRampTimeSetSpeed / Double(self.speedUp)
            if rotate {
                accelerationTime = RobotProperty.accelerationRampTimeDistanceAndRotate
            }
            else if distance {
                accelerationTime = RobotProperty.accelerationRampTimeDistanceAndRotate / Double(self.speedUp)
            }
            self.flagWheelSpeedToValue(time: accelerationTime, left: nextLeftWheelSpeed, right: nextRightWheelSpeed)
            self.leftWheelSpeed = approximateAccelerationSpeedLeft
            self.rightWheelSpeed = approximateAccelerationSpeedRight
            
            if let time = completionTime {
                let completionTimestamp = Date().timeIntervalSince1970 + time
                var a = 1
                Timer.scheduledTimer(withTimeInterval: time - 0.1, repeats: false) { _ in
                    while Date().timeIntervalSince1970 < completionTimestamp {
                        a = a + 100 * 6 % 44
                    }
                    completion()
                }
            }
        }
    }
    private let speedUp: CGFloat = 3
    private let setSpeedScalar: CGFloat = 10
    private var isRotate = false
    internal func rotate(degrees: CGFloat, completion: @escaping () -> Void) { //radians
        DispatchQueue.main.async {
            self.isRotate = true
            var correctedAngle = degrees
            if degrees < 15 && degrees > -15 {
                if degrees < 0 {
                    correctedAngle = -15
                }
                else {
                    correctedAngle = 15
                }
            }
            let rotateTime = abs(Double((CGFloat.pi / 180) * correctedAngle * RobotProperty.axelWidth * 0.5 / RobotProperty.topSpeed)) - 0.005
            self.startMovementTimestamp = Date().timeIntervalSince1970
            self.flagWheelStop(time: rotateTime)
            if correctedAngle > 0 {
                self.setWheelSpeed(leftLevel: self.setSpeedScalar/self.speedUp, rightLevel: -self.setSpeedScalar/self.speedUp, rotate: true)
            }
            else {
                self.setWheelSpeed(leftLevel: -self.setSpeedScalar/self.speedUp, rightLevel: self.setSpeedScalar/self.speedUp, rotate: true)
            }
            Timer.scheduledTimer(withTimeInterval: rotateTime + 1.0, repeats: false, block: { _ in
                completion()
            })
        }
    }
    
    internal func move(distance: CGFloat, completion: @escaping () -> Void) { // meters
        DispatchQueue.main.async {
            self.isRotate = false
            var correctedDistance = distance
            if distance < 0.08 && distance > -0.08 {
                if distance < 0 {
                    correctedDistance = -0.08
                }
                else {
                    correctedDistance = 0.08
                }
            }
            let moveTime: Double = abs(Double(correctedDistance/(RobotProperty.topSpeed*self.speedUp))) - 0.001
            self.startMovementTimestamp = Date().timeIntervalSince1970
            self.flagWheelStop(time: moveTime)
            if correctedDistance > 0 {
                self.setWheelSpeed(leftLevel: self.setSpeedScalar, rightLevel: self.setSpeedScalar, distance: true)
            }
            else {
                self.setWheelSpeed(leftLevel: -self.setSpeedScalar, rightLevel: -self.setSpeedScalar, distance: true)
            }
            Timer.scheduledTimer(withTimeInterval: moveTime + 1.0, repeats: false, block: { _ in
                completion()
            })
        }
    }
    
    internal func moveMarkerUp() {
        DispatchQueue.main.async {
            self.markerDown = false
        }
    }
    
    internal func moveMarkerDown() {
        DispatchQueue.main.async {
            self.path.first?.move(to: CGPoint(x: self.currentCenterX*UIProperty.pixelsInMeters + UIProperty.layerEdgeToCenter, y: self.currentCenterY*UIProperty.pixelsInMeters + UIProperty.layerEdgeToCenter))
            self.markerDown = true
        }
    }
}
