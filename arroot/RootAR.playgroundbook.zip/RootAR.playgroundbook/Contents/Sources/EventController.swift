//
//  EventController.swift
//
//  Copyright © 2018 Root Robotics Inc. All rights reserved.

import UIKit
import PlaygroundSupport
import ARKit

internal final class EventController {
    private weak var mainController: LiveViewController?
    private weak var markerNode: SCNNode?
    private weak var robotNode: SCNNode?
    init(mainController: LiveViewController, marker: SCNNode?, robot: SCNNode?) {
        self.mainController = mainController
        self.markerNode = marker
        self.robotNode = robot
    }
    
    private var allCommands: [(String, Int, Int, Double)] = []
    private var runOnce = false
    
    internal func queueEvents(_ message: PlaygroundValue) {
        guard case let .array(actions) = message else { return }
        let commands = actions.map { (pv) -> (String, Int, Int, Double) in
            guard case let .dictionary(dict) = pv else { return ("", 0, 0, 0.0) }
            guard case let .string(command)? = dict["command"] else { return ("", 0, 0, 0.0) }
            guard case let .integer(argInt)? = dict["argInt"] else { return ("", 0, 0, 0.0) }
            guard case let .integer(argInt2)? = dict["argInt2"] else { return ("", 0, 0, 0.0) }
            guard case let .floatingPoint(argDouble)? = dict["argDouble"] else { return ("", 0, 0, 0.0) }
            return (command, argInt, argInt2, argDouble)
        }
        allCommands += commands
        if allCommands.count > 0,
            !runOnce {
            runOnce = true
            runCommand(commands: allCommands, count: 0)
        }
    }
    
    private func runCommand(commands: [(command: String, argInt: Int, argInt2: Int, argDouble: Double)], count: Int) {
        guard commands.count > count else {
            allCommands.removeAll()
            runOnce = false
            return
        }
        switch commands[count].command {
        case "rotate":
            mainController?.robotModel.rotate(degrees: CGFloat(commands[count].argInt)) {
                self.runCommand(commands: self.allCommands, count: count + 1)
            }
        case "move":
            mainController?.robotModel.move(distance: CGFloat(commands[count].argInt)/100) {
                self.runCommand(commands: self.allCommands, count: count + 1)
            }
        case "marker":
            if commands[count].argInt == 1 {
                mainController?.robotModel.moveMarkerDown()
                markerNode?.runAction(SCNAction.move(to: SCNVector3(0, 25, 0), duration: 0.5))
                markerNode?.opacity = 1.0
            }
            else {
                mainController?.robotModel.moveMarkerUp()
                resetMarker()
            }
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.45) {
                self.runCommand(commands: self.allCommands, count: count + 1)
            }
        case "setWheels":
            if commands.count > count + 1,
                commands[count + 1].command == "wait" {
                let time = Double(commands[count + 1].argDouble)
                mainController?.robotModel.setWheelSpeed(leftLevel: CGFloat(commands[count].argInt), rightLevel: CGFloat(commands[count].argInt2), completionTime: time) {
                    self.runCommand(commands: self.allCommands, count: count + 2)
                }
            }
            else if commands[count].argInt == 0 && commands[count].argInt2 == 0 {
                mainController?.robotModel.setWheelSpeed(leftLevel: CGFloat(commands[count].argInt), rightLevel: CGFloat(commands[count].argInt2), completionTime: 0) {
                    self.runCommand(commands: self.allCommands, count: count + 1)
                }
            }
            else {
                self.runCommand(commands: self.allCommands, count: count + 1)
            }
        case "wait":
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(commands[count].argDouble)) {
                self.runCommand(commands: self.allCommands, count: count + 1)
            }
        case "place":
            mainController?.placeRobot()
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.0) {
                self.runCommand(commands: self.allCommands, count: count + 1)
            }
        default:
            return
        }
    }
    
    internal func updateRobotView() {
        DispatchQueue.main.async {
            guard let robotModel = self.mainController?.robotModel else { return }
            let move = SCNAction.move(to: SCNVector3(robotModel.currentCenterY, -robotModel.currentCenterX, 0.032), duration: 0.0)
            self.robotNode?.runAction(move)
            let rotate = SCNAction.rotateTo(x: CGFloat.pi/2, y: 0, z: robotModel.heading, duration: 0.0)
            self.robotNode?.runAction(rotate)
        }
    }
    
    internal func resetMarker() {
        markerNode?.runAction(SCNAction.move(to: SCNVector3(0, 100, 0), duration: 0.5))
        markerNode?.opacity = 0.5
    }
    
    internal func removeAllCommands() {
        allCommands.removeAll()
    }
}
