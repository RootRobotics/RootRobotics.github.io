//#-hidden-code
//
//  VirtualRobotModel.swift
//
//  Copyright © 2018 Root Robotics Inc. All rights reserved.

import PlaygroundSupport

let proxy = PlaygroundPage.current.liveView as? PlaygroundRemoteLiveViewProxy

PlaygroundPage.current.needsIndefiniteExecution = true

public final class Root {
    private var whenProgramStartedActions: [PlaygroundValue] = []
    
    public func whenProgramStarted(_ actions: () -> Void) {
        whenProgramStartedActions.removeAll()
        actions()
        proxy?.send(.array(whenProgramStartedActions))
    }
    
    public func place() {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("place"), "argInt": PlaygroundValue.integer(0), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }

    public func move(_ cm: Int = 16) {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("move"), "argInt": PlaygroundValue.integer(cm), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }
    
    public func speeds(left: Int = 10, right: Int = 10) {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("setWheels"), "argInt": PlaygroundValue.integer(left), "argInt2": PlaygroundValue.integer(right), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }
    
    public func wait(sec: Double) {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("wait"), "argInt": PlaygroundValue.integer(0), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(sec)]))
    }

    public func turn(_ deg: Int = 90) {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("rotate"), "argInt": PlaygroundValue.integer(deg), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }

    public func markerDown() {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("marker"), "argInt": PlaygroundValue.integer(1), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }

    public func markerAndEraserUp() {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("marker"), "argInt": PlaygroundValue.integer(0), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }
}
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, robot, ., move(_:), turn(_:), markerDown(), markerAndEraserUp(), for, wait(sec:), speeds(left:right:), var)

//#-end-hidden-code

/*:#localized(key: "FirstProseBlock")
 #  Root Graffiti
 
 Let’s unleash your inner robot graffiti artist. Use the move, turn and draw commands to code Root to draw the first letter of your name.
 
 Writing Letters is a lot like drawing shapes. If you need help getting started, find the diagram of the letter you want to draw from the Root Alphabet.
 
 ![image](RootAlphabet.png)
 
 Bonus: Can you code Root to write your entire name?
 
 */
let robot = Root()

robot.whenProgramStarted {
    robot.place()
    //#-editable-code
    
    //#-end-editable-code
}
