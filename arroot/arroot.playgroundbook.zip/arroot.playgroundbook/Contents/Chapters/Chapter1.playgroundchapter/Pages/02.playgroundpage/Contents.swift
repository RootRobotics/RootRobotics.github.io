//#-hidden-code
//
//  VirtualRobotModel.swift
//
//  Copyright © 2018 Root Robotics Inc. All rights reserved.

import PlaygroundSupport

let proxy = PlaygroundPage.current.liveView as? PlaygroundRemoteLiveViewProxy

PlaygroundPage.current.needsIndefiniteExecution = true

public final class Root {
    private var whenProgramStartedActions: [PlaygroundValue] = []
    
    public func whenProgramStarted(_ actions: () -> Void) {
        whenProgramStartedActions.removeAll()
        actions()
        proxy?.send(.array(whenProgramStartedActions))
    }
    
    public func place() {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("place"), "argInt": PlaygroundValue.integer(0), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }

    public func move(_ cm: Int = 16) {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("move"), "argInt": PlaygroundValue.integer(cm), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }
    
    public func speeds(left: Int, right: Int) {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("setWheels"), "argInt": PlaygroundValue.integer(left), "argInt2": PlaygroundValue.integer(right), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }
    
    public func wait(sec: Double) {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("wait"), "argInt": PlaygroundValue.integer(0), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(sec)]))
    }

    public func turn(_ deg: Int = 90) {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("rotate"), "argInt": PlaygroundValue.integer(deg), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }

    public func markerDown() {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("marker"), "argInt": PlaygroundValue.integer(1), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }

    public func markerAndEraserUp() {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("marker"), "argInt": PlaygroundValue.integer(0), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }
}
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, robot, ., move(_:), turn(_:))

//#-end-hidden-code

/*:#localized(key: "FirstProseBlock")
 # Get Root Moving
 
 You can code Virtual Root to move and turn. Run the code to see Root move a very short distance.
 
 Can you edit the `robot.move()` command to make Root move further?
 
![image](moveForward.png)
 
 After the robot.move command, try adding a `robot.turn()` command.
 */
let robot = Root()

robot.whenProgramStarted {
    robot.place()
    //#-editable-code
    robot.move(16)
    
    //#-end-editable-code
}
