//
//  LiveViewController.swift
//
//  Copyright © 2018 Root Robotics Inc. All rights reserved.

import UIKit
import PlaygroundSupport
import ARKit
import CoreGraphics
import AVFoundation

@objc(Book_Sources_LiveViewController)
public class LiveViewController: UIViewController {
    
    @IBOutlet weak var arView: ARSCNView!
    private weak var scene: SCNScene?
    private let overlayViews = OverlayViews()
    private lazy var eventController = EventController(mainController: self, marker: markerNode, robot: robotNode)
    internal var robotModel = VirtualRobotModel()
    
    private weak var wrapperNode: SCNNode?
    private weak var correctionNode: SCNNode?
    private weak var canvasNode: SCNNode?
    private weak var targetNode: SCNNode?
    public weak var robotNode: SCNNode?
    private weak var markerNode: SCNNode?
    private weak var drawShapeLayer: CAShapeLayer?
    
    private var canvasAttached: Bool = false
    private var isRobotVisible = false {
        didSet {
            overlayViews.hideAlert(isRobotVisible)
        }
    }
    private var isStillOrientating: Bool = true
    private var planeGeometry: [ARAnchor: SCNPlane] = [:]
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        setupScene()
        resetAR()
        CADisplayLink(target: robotModel, selector: #selector(robotModel.update)).add(to: .current, forMode: .common)
    }
    
    private func reset() {
        DispatchQueue.main.async {
            self.arView.scene = SCNScene()
            self.removePath()
            self.removeRobot()
            self.planeGeometry.removeAll()
            self.arView.session.pause()
            self.arView.removeFromSuperview()
            AudioServicesPlaySystemSound(1016)
        }
    }
    
    private func setupScene() {
        DispatchQueue.main.async {
            self.arView.delegate = self
            self.arView.automaticallyUpdatesLighting = false
            self.scene = self.arView.scene
            self.overlayViews.setupSubviews(in: self.view)
            let path = UIBezierPath()
            self.robotModel.path.append(path)
            self.addLighting()
        }
    }
    
    private func resetAR() {
        DispatchQueue.main.async {
            let arConfig = ARWorldTrackingConfiguration()

            if #available(iOS 11.3, *) {
                arConfig.planeDetection = [.horizontal, .vertical]
            } else {
                arConfig.planeDetection = [.horizontal]
            }
            self.arView.session.run(arConfig, options: [.resetTracking, .removeExistingAnchors])
            
            let drawShapeLayer: CAShapeLayer = {
                let layer = CAShapeLayer()
                layer.frame = CGRect(x: 0, y: 0, width: UIProperty.layerEdgeToCenter * 2, height: UIProperty.layerEdgeToCenter * 2)
                layer.lineCap = .round
                layer.lineWidth = 15
                layer.strokeColor = UIColor(red: 21/255, green: 100/255, blue: 252/255, alpha: 0.8).cgColor
                layer.backgroundColor = UIColor.clear.cgColor
                return layer
            }()
            drawShapeLayer.path = self.robotModel.path.first?.cgPath
            let wrapperNode = SCNNode()
            let correctionNode = SCNNode()
            let canvasNode: SCNNode = {
                let node = SCNNode()
                let plane = SCNPlane(width: UIProperty.layerEdgeToCenter/1000, height: UIProperty.layerEdgeToCenter/1000)
                let material = SCNMaterial()
                material.lightingModel = .phong
                material.diffuse.contents = drawShapeLayer
                plane.materials = [material]
                node.geometry = plane
                return node
            }()
            let targetNode: SCNNode = {
                let node = SCNNode()
                let planeSelector = SCNPlane(width: UIProperty.layerEdgeToCenter/12000, height: UIProperty.layerEdgeToCenter/10000)
                let planeSelectorMaterial = SCNMaterial()
                planeSelectorMaterial.diffuse.contents = UIImage(named: "planeSelector")
                planeSelectorMaterial.lightingModel = .phong
                planeSelector.materials = [planeSelectorMaterial]
                node.geometry = planeSelector
                return node
            }()
            
            self.wrapperNode = wrapperNode
            self.correctionNode = correctionNode
            self.canvasNode = canvasNode
            self.targetNode = targetNode
            self.drawShapeLayer = drawShapeLayer
            
            let robotFromFile = SCNNode(named: "Root.scnassets/robot.dae")
            let markerFromFile = SCNNode(named: "Root.scnassets/marker.dae")
            robotFromFile.geometry?.firstMaterial?.lightingModel = .physicallyBased
            self.robotNode = robotFromFile
            markerFromFile.geometry?.firstMaterial?.lightingModel = .physicallyBased
            self.markerNode = markerFromFile
            
            self.scene?.rootNode.addChildNode(wrapperNode)
            wrapperNode.addChildNode(correctionNode)
            correctionNode.addChildNode(canvasNode)
            correctionNode.addChildNode(targetNode)
            correctionNode.addChildNode(robotFromFile)
            robotFromFile.addChildNode(markerFromFile)
            wrapperNode.isHidden = true
            
            robotFromFile.transform = SCNMatrix4MakeScale(0.001, 0.001, 0.001)
            correctionNode.transform = SCNMatrix4MakeRotation(-Float.pi/2, 1, 0, 0)
            canvasNode.transform = SCNMatrix4MakeRotation(-Float.pi/2, 0, 0, 1)
            targetNode.transform = SCNMatrix4MakeTranslation(0, -0.01, 0.01)
            let rotate = SCNAction.rotateTo(x: CGFloat.pi/2, y: 0, z: self.robotModel.heading, duration: 0.0)
            self.robotNode?.runAction(rotate)
            let move = SCNAction.move(to: SCNVector3(self.robotModel.currentCenterY, -self.robotModel.currentCenterX, 0.032), duration: 0.0)
            self.robotNode?.runAction(move)
            self.markerNode?.runAction(SCNAction.move(to: SCNVector3(0, 100, 0), duration: 0.5))
            self.markerNode?.opacity = 0.5
        }
    }
    
    @IBAction func viewTapped(_ sender: Any) {
        placeRobot()
    }
    
    private func addLighting() {
        let directionalLight = SCNNode()
        let light = SCNLight()
        directionalLight.light = light
        light.type = .directional
        directionalLight.eulerAngles = SCNVector3(x: -110, y: -11, z: -28)
        directionalLight.position = SCNVector3(325, 635, 75)
        scene?.rootNode.addChildNode(directionalLight)
        
        let directionalLight2 = SCNNode()
        let light2 = SCNLight()
        directionalLight2.light = light2
        light2.type = .directional
        directionalLight2.eulerAngles = SCNVector3(x: -17, y: 0, z: 0)
        directionalLight2.position = SCNVector3(-35, 600, 510)
        scene?.rootNode.addChildNode(directionalLight2)
    }
    
    private func createPlaneSCNNode(anchor: ARPlaneAnchor) -> SCNNode {
        let geometry = SCNPlane(width: CGFloat(anchor.extent.x), height: CGFloat(anchor.extent.z))
        let material = SCNMaterial()
        material.diffuse.contents = UIColor.clear
        geometry.materials = [material]
        let node = SCNNode(geometry: geometry)
        node.position = SCNVector3(anchor.center.x, 0, anchor.center.z)
        node.transform =  SCNMatrix4MakeRotation(-Float.pi*0.5, 1, 0, 0)
        planeGeometry[anchor] = geometry
        return node
    }
    
    private func updatePlaneSCNNode(planeNode: SCNNode, planeAnchor: ARPlaneAnchor) {
        if let geometry = planeNode.geometry as? SCNPlane {
            geometry.width = CGFloat(planeAnchor.extent.x)
            geometry.height = CGFloat(planeAnchor.extent.z)
            planeNode.position = SCNVector3Make(planeAnchor.center.x, 0, planeAnchor.center.z)
        }
    }
    
    private func highlight(plane: SCNPlane, on: Bool) {
        DispatchQueue.main.async {
            let material = SCNMaterial()
            if on {
                material.diffuse.contents = UIColor.white.withAlphaComponent(0.2)
            }
            else {
                material.diffuse.contents = UIColor.clear
            }
            plane.materials = [material]
        }
    }
    
    private func removeAllHightlights() {
        self.planeGeometry.forEach { self.highlight(plane: $0.value, on: false) }
    }
    
    private func showRobotTarget(at location: simd_float4x4) {
        wrapperNode?.isHidden = false
        wrapperNode?.transform = SCNMatrix4(location)
        isStillOrientating = false
    }
    
    @objc private func hitTest() {
        if !canvasAttached {
            hitTestCenterAndPlaceOutlineOfRobot()
        }
    }
    
    private func hitTestCenterAndPlaceOutlineOfRobot() {
        DispatchQueue.main.async {
            guard !self.isRobotVisible else { return }
            let results = self.arView.hitTest(self.arView.center, types: .existingPlaneUsingExtent)
            if let hit = results.last {
                if let anchor = hit.anchor, let plane = self.planeGeometry[anchor] {
                    self.highlight(plane: plane, on: true)
                }
                self.showRobotTarget(at: hit.worldTransform)
                self.overlayViews.alert("Run code to place robot")
                self.overlayViews.hideTarget(true)
                self.wrapperNode?.isHidden = false
            }
            else if !self.isStillOrientating {
                self.overlayViews.alert("Move to find a surface")
                self.overlayViews.hideTarget(false)
                self.removeAllHightlights()
                self.wrapperNode?.isHidden = true
            }
        }
    }
    
    internal func placeRobot() {
        DispatchQueue.main.async {
            self.isRobotVisible = true
            self.targetNode?.opacity = 0.0
            self.overlayViews.hideTarget(true)
            self.canvasAttached = true
            self.removeAllHightlights()
            self.robotModel.path.first?.removeAllPoints()
            self.robotModel.path.removeAll()
            let path = UIBezierPath()
            self.robotModel.path.append(path)
            let rotate = SCNAction.rotateTo(x: CGFloat.pi/2, y: 0, z: self.robotModel.heading, duration: 0.0)
            self.robotNode?.runAction(rotate)
            let move = SCNAction.move(to: SCNVector3(self.robotModel.currentCenterY, -self.robotModel.currentCenterX, 0.032), duration: 0.0)
            self.robotNode?.runAction(move)
        }
    }
    
    private func removeRobot() {
        DispatchQueue.main.async {
            self.eventController.removeAllCommands()
            self.robotModel.setWheelSpeed(leftLevel: 0, rightLevel: 0)
            self.targetNode?.opacity = 1.0
            self.overlayViews.hideTarget(false)
            self.canvasAttached = false
            self.isRobotVisible = false
        }
    }
    
    private func removePath() {
        DispatchQueue.main.async {
            self.robotModel.moveMarkerUp()
            self.robotModel.currentCenterX = 0.0
            self.robotModel.currentCenterY = 0.0
            self.robotModel.heading = 0.0
            self.robotModel.path.first?.removeAllPoints()
            self.robotModel.path.removeAll()
            self.isStillOrientating = true
            self.eventController.resetMarker()
        }
    }
    
    private var count = 0
    private func updatePlaneView() {
        DispatchQueue.main.async {
            self.count += 1
            if self.count%10 == 0 {
                self.drawShapeLayer?.path = self.robotModel.path.first?.cgPath
            }
        }
    }
}

extension LiveViewController: PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer {
    public func liveViewMessageConnectionClosed() {
        DispatchQueue.main.async {
            self.removeRobot()
            self.removePath()
        }
    }
    
    public func receive(_ message: PlaygroundValue) {
        eventController.queueEvents(message)
    }
}

extension LiveViewController: ARSCNViewDelegate, ARSessionDelegate {
    public func renderer(_ renderer: SCNSceneRenderer, didUpdate node: SCNNode, for anchor: ARAnchor) {
        DispatchQueue.main.async {
            guard let planeAnchor = anchor as? ARPlaneAnchor else { return }
            if let node = node.childNodes.first {
                self.updatePlaneSCNNode(planeNode: node, planeAnchor: planeAnchor)
            }
        }
    }
    
    public func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
        DispatchQueue.main.async {
            guard let planeAnchor = anchor as? ARPlaneAnchor else { return }
            let planeNode = self.createPlaneSCNNode(anchor: planeAnchor)
            node.addChildNode(planeNode)
        }
    }
    
    public func renderer(_ renderer: SCNSceneRenderer, didRemove node: SCNNode, for anchor: ARAnchor) {
        DispatchQueue.main.async {
            guard anchor is ARPlaneAnchor else { return }
            if node == self.wrapperNode?.parent {
                self.canvasAttached = false
            }
        }
    }
    
    public func renderer(_ renderer: SCNSceneRenderer, updateAtTime time: TimeInterval) {
        DispatchQueue.main.async {
            self.eventController.updateRobotView()
            self.updatePlaneView()
            self.hitTest()
        }
    }
}

extension LiveViewController: ARSessionObserver {
    public func sessionWasInterrupted(_ session: ARSession) {
        overlayViews.alert("AR session was interupted")
    }
    public func sessionInterruptionEnded(_ session: ARSession) {
        resetAR()
    }
    public func session(_ session: ARSession, didFailWithError error: Error) {
        overlayViews.alert("AR session failed: \(error.localizedDescription)")
    }
    public func session(_ session: ARSession, cameraDidChangeTrackingState camera: ARCamera) {
        if isStillOrientating {
            switch camera.trackingState {
            case .notAvailable:
                overlayViews.alert("Tracking not available")
            case .limited(.initializing):
                overlayViews.alert("Initializing AR session")
            case .limited(.excessiveMotion):
                overlayViews.alert("Too much motion")
            case .limited(.insufficientFeatures):
                overlayViews.alert("Not enough surface details")
            case .normal:
                overlayViews.alert("Move to find a surface")
            default:
                overlayViews.alert(nil)
            }
        }
        else if !isRobotVisible {
            overlayViews.alert("Run code to place robot")
        }
        else {
            overlayViews.alert(nil)
        }
    }
}

extension SCNNode {
    
    convenience init(named name: String) {
        self.init()
        
        guard let scene = SCNScene(named: name) else {
            return
        }
        
        for childNode in scene.rootNode.childNodes {
            addChildNode(childNode)
        }
    }
    
}
