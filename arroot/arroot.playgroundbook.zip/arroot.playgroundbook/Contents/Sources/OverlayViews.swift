//
//  OverlayViews.swift
//
//  Copyright © 2018 Root Robotics Inc. All rights reserved.

import UIKit
import PlaygroundSupport

internal final class OverlayViews {
    private lazy var target: UIView = {
        let view = UIView()
        view.layer.cornerRadius = 2
        view.clipsToBounds = true
        view.backgroundColor = .white
        return view
    }()
    private class MessageLabel: UILabel {
        let topInset: CGFloat = 10
        let bottomInset: CGFloat = 10
        let leftInset: CGFloat = 30
        let rightInset: CGFloat = 30
        override func drawText(in rect: CGRect) {
            let insets = UIEdgeInsets.init(top: topInset, left: leftInset, bottom: bottomInset, right: rightInset)
            super.drawText(in: rect.inset(by: insets))
        }
        override var intrinsicContentSize: CGSize {
            let size = super.intrinsicContentSize
            return CGSize(width: size.width + leftInset + rightInset,
                          height: size.height + topInset + bottomInset)
        }
    }
    private lazy var messageLabel: MessageLabel = {
        let label = MessageLabel()
        label.layer.cornerRadius = 2
        label.clipsToBounds = true
        label.backgroundColor = UIColor.white.withAlphaComponent(0.8)
        label.font = UIFont(name: "Helvetica-Neue", size: 14)
        label.textColor = .black
        return label
    }()
    
    internal func setupSubviews(in view: UIView) {
        view.addSubview(target)
        target.translatesAutoresizingMaskIntoConstraints = false
        target.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        target.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        target.widthAnchor.constraint(equalToConstant: 4).isActive = true
        target.heightAnchor.constraint(equalToConstant: 4).isActive = true
        view.addSubview(messageLabel)
        messageLabel.translatesAutoresizingMaskIntoConstraints = false
        messageLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 20).isActive = true
        messageLabel.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -20).isActive = true
    }
    
    internal func hideTarget(_ isHidden: Bool) {
        target.isHidden = isHidden
    }
    internal func alert(_ message: String?) {
        DispatchQueue.main.async {
        self.hideAlert(message == nil)
        self.messageLabel.text = message
        }
    }
    internal func hideAlert(_ isHidden: Bool) {
        DispatchQueue.main.async {
        self.messageLabel.isHidden = isHidden
        }
    }
}
