//
//  LiveViewSupport.swift
//
//  Copyright © 2018 Root Robotics Inc. All rights reserved.

import UIKit
import PlaygroundSupport

public func instantiateLiveView() -> PlaygroundLiveViewable {
    let storyboard = UIStoryboard(name: "LiveView", bundle: nil)
    return storyboard.instantiateInitialViewController() as! LiveViewController
}
