//#-hidden-code
//
//  VirtualRobotModel.swift
//
//  Copyright © 2018 Root Robotics Inc. All rights reserved.

import PlaygroundSupport

let proxy = PlaygroundPage.current.liveView as? PlaygroundRemoteLiveViewProxy

PlaygroundPage.current.needsIndefiniteExecution = true

public final class Root {
    private var whenProgramStartedActions: [PlaygroundValue] = []
    
    public func whenProgramStarted(_ actions: () -> Void) {
        whenProgramStartedActions.removeAll()
        actions()
        proxy?.send(.array(whenProgramStartedActions))
    }
    
    public func place() {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("place"), "argInt": PlaygroundValue.integer(0), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }

    public func move(_ cm: Int = 16) {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("move"), "argInt": PlaygroundValue.integer(cm), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }
    
    public func speeds(left: Int, right: Int) {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("setWheels"), "argInt": PlaygroundValue.integer(left), "argInt2": PlaygroundValue.integer(right), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }
    
    public func wait(sec: Double) {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("wait"), "argInt": PlaygroundValue.integer(0), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(sec)]))
    }

    public func turn(_ deg: Int = 90) {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("rotate"), "argInt": PlaygroundValue.integer(deg), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }

    public func markerDown() {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("marker"), "argInt": PlaygroundValue.integer(1), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }

    public func markerAndEraserUp() {
        whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("marker"), "argInt": PlaygroundValue.integer(0), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }
}
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, robot, ., move(_:), turn(_:), markerDown(), markerAndEraserUp(), for)

//#-end-hidden-code

/*:#localized(key: "FirstProseBlock")
 #  Loops
 
 Now that you know how to make Root move and draw, let’s try using a loop to create a square.
 
 Run the code to see Root draw half of a square.
 
 Can you edit how many times the code loops to complete the square?

 */
let robot = Root()

robot.whenProgramStarted {
    robot.place()
    robot.markerDown()
    //#-editable-code
    for i in 1 ... 2 {
        robot.move(16)
        robot.turn(90)
    }
    //#-end-editable-code
}
