//
//  LiveViewController.swift
//
//  Copyright © 2018 Root Robotics Inc. All rights reserved.

import UIKit
import PlaygroundSupport
import ARKit
import CoreGraphics

@objc(Book_Sources_LiveViewController)
public class LiveViewController: UIViewController {
    
    @IBOutlet weak var arView: ARSCNView!
   
    private let scene = SCNScene(named: "Root.scnassets/Root-marker.scn")
    private let overlayViews = OverlayViews()
    private lazy var eventController = EventController(mainController: self, marker: markerNode, robot: robotNode)
    internal var robotModel = VirtualRobotModel()
    
    private let wrapperNode: SCNNode = SCNNode()
    private let correctionNode: SCNNode = SCNNode()
    private lazy var canvasNode: SCNNode = {
        let node = SCNNode()
        let plane = SCNPlane(width: UIProperty.layerEdgeToCenter/1000, height: UIProperty.layerEdgeToCenter/1000)
        let material = SCNMaterial()
        material.lightingModel = .physicallyBased
        material.diffuse.contents = drawShapeLayer
        plane.materials = [material]
        node.geometry = plane
        return node
    }()
    private let targetNode: SCNNode = {
        let node = SCNNode()
        let planeSelector = SCNPlane(width: UIProperty.layerEdgeToCenter/12000, height: UIProperty.layerEdgeToCenter/10000)
        let planeSelectorMaterial = SCNMaterial()
        planeSelectorMaterial.diffuse.contents = UIImage(named: "planeSelector")
        planeSelectorMaterial.lightingModel = .phong
        planeSelector.materials = [planeSelectorMaterial]
        node.geometry = planeSelector
        return node
    }()
    public var robotNode = SCNNode()
    private var markerNode = SCNNode()
    private var sceneBaseNode = SCNNode()
    
    private var drawShapeLayer: CAShapeLayer = {
        let layer = CAShapeLayer()
        layer.frame = CGRect(x: 0, y: 0, width: UIProperty.layerEdgeToCenter * 2, height: UIProperty.layerEdgeToCenter * 2)
        layer.lineCap = .round
        layer.lineWidth = 15
        layer.strokeColor = UIColor.blue.cgColor
        layer.backgroundColor = UIColor.clear.cgColor
        return layer
    }()
    
    private var canvasAttached: Bool = false
    
    private var isRobotVisible = false {
        didSet {
            overlayViews.hideAlert(isRobotVisible)
        }
    }
    private var isStillOrientating: Bool = true
    
    private var planeGeometry: [ARAnchor: SCNPlane] = [:]
    
    override public func viewDidLoad() {
        super.viewDidLoad()
         setupScene()
    }
    public override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        resetAR()
    }
    
    private func setupScene() {
        DispatchQueue.main.async {
            self.arView.delegate = self
            self.arView.automaticallyUpdatesLighting = false
            guard let scene = self.scene else { return }
            self.arView.scene = scene
            self.sceneBaseNode = scene.rootNode
            self.overlayViews.setupSubviews(in: self.arView)
            if let node = scene.rootNode.childNode(withName: "root", recursively: false) {
                node.geometry?.firstMaterial?.lightingModel = .physicallyBased
                self.robotNode = node
            }
            if let node = scene.rootNode.childNode(withName: "marker", recursively: true) {
                node.geometry?.firstMaterial?.lightingModel = .physicallyBased
                self.markerNode = node
            }
            
            self.correctionNode.transform = SCNMatrix4MakeRotation(-Float.pi/2, 1, 0, 0)
            self.canvasNode.transform = SCNMatrix4MakeRotation(-Float.pi/2, 0, 0, 1)
            self.targetNode.transform = SCNMatrix4MakeTranslation(0, -0.01, 0.01)
            let rotate = SCNAction.rotateTo(x: CGFloat.pi/2, y: 0, z: self.robotModel.heading, duration: 0.0)
            self.robotNode.runAction(rotate)
        }
    }
    
    private func resetAR() {
        DispatchQueue.main.async {
            let arConfig = ARWorldTrackingConfiguration()

            if #available(iOS 11.3, *) {
                arConfig.planeDetection = [.horizontal, .vertical]
            } else {
                arConfig.planeDetection = [.horizontal]
            }
            self.arView.session.run(arConfig, options: [.resetTracking, .removeExistingAnchors])
            
            self.sceneBaseNode.addChildNode(self.wrapperNode)
            self.wrapperNode.addChildNode(self.correctionNode)
            self.correctionNode.addChildNode(self.canvasNode)
            self.correctionNode.addChildNode(self.targetNode)
            self.correctionNode.addChildNode(self.robotNode)
            self.wrapperNode.isHidden = true
        }
    }
    
    @IBAction func viewTapped(_ sender: Any) {
        placeRobot()
    }
    
    private func createPlaneSCNNode(anchor: ARPlaneAnchor) -> SCNNode {
        let geometry = SCNPlane(width: CGFloat(anchor.extent.x), height: CGFloat(anchor.extent.z))
        let material = SCNMaterial()
        material.diffuse.contents = UIColor.clear
        geometry.materials = [material]
        let node = SCNNode(geometry: geometry)
        node.position = SCNVector3(anchor.center.x, 0, anchor.center.z)
        node.transform =  SCNMatrix4MakeRotation(-Float.pi*0.5, 1, 0, 0)
        planeGeometry[anchor] = geometry
        return node
    }
    
    private func updatePlaneSCNNode(planeNode: SCNNode, planeAnchor: ARPlaneAnchor) {
        if let geometry = planeNode.geometry as? SCNPlane {
            geometry.width = CGFloat(planeAnchor.extent.x)
            geometry.height = CGFloat(planeAnchor.extent.z)
            planeNode.position = SCNVector3Make(planeAnchor.center.x, 0, planeAnchor.center.z)
        }
    }
    
    private func highlight(plane: SCNPlane, on: Bool) {
        DispatchQueue.main.async {
            let material = SCNMaterial()
            if on {
                material.diffuse.contents = UIColor.white.withAlphaComponent(0.2)
            }
            else {
                material.diffuse.contents = UIColor.clear
            }
            plane.materials = [material]
        }
    }
    
    private func removeAllHightlights() {
        self.planeGeometry.forEach { self.highlight(plane: $0.value, on: false) }
    }
    
    private func showRobotTarget(at location: simd_float4x4) {
        wrapperNode.isHidden = false
        wrapperNode.transform = SCNMatrix4(location)
        isStillOrientating = false
    }
    
    @objc private func hitTest() {
        if !canvasAttached {
            hitTestCenterAndPlaceOutlineOfRobot()
        }
    }
    
    private func hitTestCenterAndPlaceOutlineOfRobot() {
        DispatchQueue.main.async {
            guard !self.isRobotVisible else { return }
            let results = self.arView.hitTest(self.arView.center, types: .existingPlaneUsingExtent)
            if let hit = results.last {
                if let anchor = hit.anchor, let plane = self.planeGeometry[anchor] {
                    self.highlight(plane: plane, on: true)
                }
                self.showRobotTarget(at: hit.worldTransform)
                self.overlayViews.alert("Run code to place robot")
                self.overlayViews.hideTarget(true)
                self.wrapperNode.isHidden = false
            }
            else if !self.isStillOrientating {
                self.overlayViews.alert("Move to find a surface")
                self.overlayViews.hideTarget(false)
                self.removeAllHightlights()
                self.wrapperNode.isHidden = true
            }
        }
    }
    
    internal func placeRobot() {
        DispatchQueue.main.async {
            self.isRobotVisible = true
            self.targetNode.opacity = 0.0
            self.overlayViews.hideTarget(true)
            self.canvasAttached = true
            self.removeAllHightlights()
        }
    }
    
    private func removeRobot() {
        DispatchQueue.main.async {
            self.eventController.removeAllCommands()
            self.robotModel.setWheelSpeed(leftLevel: 0, rightLevel: 0)
            self.targetNode.opacity = 1.0
            self.overlayViews.hideTarget(false)
            self.canvasAttached = false
            self.isRobotVisible = false
        }
    }
    
    private func removePath() {
        DispatchQueue.main.async {
            self.robotModel.moveMarkerUp()
            self.robotModel.currentCenterX = 0.0
            self.robotModel.currentCenterY = 0.0
            self.robotModel.heading = 0.0
            self.robotModel.path.removeAllPoints()
            self.isStillOrientating = true
            self.eventController.resetMarker()
        }
    }
    
    private var count = 0
    private func updatePlaneView() {
        DispatchQueue.main.async {
            self.count += 1
            if self.count%10 == 0 {
                self.drawShapeLayer.path = self.robotModel.path.cgPath
            }
        }
    }
    private func updateLighting() {
        let max: CGFloat = 2.2
        var intensity = (arView.session.currentFrame?.lightEstimate?.ambientIntensity ?? 1000) / 180
        if intensity > max {
            intensity = max
        }
        scene?.lightingEnvironment.intensity = intensity
    }
}

extension LiveViewController: PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer {
    public func liveViewMessageConnectionClosed() {
        DispatchQueue.main.async {
            self.removeRobot()
            self.removePath()
        }
    }
    
    public func receive(_ message: PlaygroundValue) {
        eventController.queueEvents(message)
    }
}

extension LiveViewController: ARSCNViewDelegate, ARSessionDelegate {
    public func renderer(_ renderer: SCNSceneRenderer, didUpdate node: SCNNode, for anchor: ARAnchor) {
        DispatchQueue.main.async {
            guard let planeAnchor = anchor as? ARPlaneAnchor else { return }
            if let node = node.childNodes.first {
                self.updatePlaneSCNNode(planeNode: node, planeAnchor: planeAnchor)
            }
        }
    }
    
    public func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
        DispatchQueue.main.async {
            guard let planeAnchor = anchor as? ARPlaneAnchor else { return }
            let planeNode = self.createPlaneSCNNode(anchor: planeAnchor)
            node.addChildNode(planeNode)
        }
    }
    
    public func renderer(_ renderer: SCNSceneRenderer, didRemove node: SCNNode, for anchor: ARAnchor) {
        DispatchQueue.main.async {
            guard anchor is ARPlaneAnchor else { return }
            if node == self.wrapperNode.parent {
                self.canvasAttached = false
            }
        }
    }
    
    public func renderer(_ renderer: SCNSceneRenderer, updateAtTime time: TimeInterval) {
        DispatchQueue.main.async {
            self.eventController.updateRobotView()
            self.updatePlaneView()
            self.hitTest()
            self.updateLighting()
        }
    }
}

extension LiveViewController: ARSessionObserver {
    public func sessionWasInterrupted(_ session: ARSession) {
        overlayViews.alert("AR session was interupted")
    }
    public func sessionInterruptionEnded(_ session: ARSession) {
        resetAR()
    }
    public func session(_ session: ARSession, didFailWithError error: Error) {
        overlayViews.alert("AR session failed: \(error.localizedDescription)")
    }
    public func session(_ session: ARSession, cameraDidChangeTrackingState camera: ARCamera) {
        if isStillOrientating {
            switch camera.trackingState {
            case .notAvailable:
                overlayViews.alert("Tracking not available")
            case .limited(.initializing):
                overlayViews.alert("Initializing AR session")
            case .limited(.excessiveMotion):
                overlayViews.alert("Too much motion")
            case .limited(.insufficientFeatures):
                overlayViews.alert("Not enough surface details")
            case .normal:
                overlayViews.alert("Move to find a surface")
            default:
                overlayViews.alert(nil)
            }
        }
        else if !isRobotVisible {
            overlayViews.alert("Run code to place robot")
        }
        else {
            overlayViews.alert(nil)
        }
    }
}
