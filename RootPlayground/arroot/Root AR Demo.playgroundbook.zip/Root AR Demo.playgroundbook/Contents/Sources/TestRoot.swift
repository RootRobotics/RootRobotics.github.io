//
//  TestRoot.swift
//
//  Copyright © 2019 Root Robotics Inc. All rights reserved.

import UIKit
import PlaygroundSupport

class TestRoot {
    
    static var whenProgramStartedActions: [PlaygroundValue] = []
    
    static func whenProgramStarted(_ actions: () -> Void) {
        whenProgramStartedActions.removeAll()
        actions()
        
    }
    
    static func place() {
        TestRoot.whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("place"), "argInt": PlaygroundValue.integer(0), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }
    
    static func move(_ cm: Int) {
        TestRoot.whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("move"), "argInt": PlaygroundValue.integer(cm), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }
    
    static func speeds(left: Int, right: Int) {
        TestRoot.whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("setWheels"), "argInt": PlaygroundValue.integer(left), "argInt2": PlaygroundValue.integer(right), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }
    
    static func wait(sec: Int) {
        TestRoot.whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("wait"), "argInt": PlaygroundValue.integer(sec), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }
    
    static func turn(_ deg: Int) {
        TestRoot.whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("rotate"), "argInt": PlaygroundValue.integer(deg), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }
    
    static func markerDown() {
        TestRoot.whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("marker"), "argInt": PlaygroundValue.integer(1), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }
    
    static func markerAndEraserUp() {
        TestRoot.whenProgramStartedActions.append(PlaygroundValue.dictionary(["command": PlaygroundValue.string("marker"), "argInt": PlaygroundValue.integer(0), "argInt2": PlaygroundValue.integer(0), "argDouble": PlaygroundValue.floatingPoint(0.0)]))
    }
}
